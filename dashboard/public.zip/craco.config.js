module.exports = {
  devServer: {
    allowedHosts: 'all',
    host: 'localhost',
    port: 3001,
    hot: true,
    open: true
  }
};
