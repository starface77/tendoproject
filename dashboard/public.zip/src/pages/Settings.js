import React from 'react';

const Settings = () => {
  return (
    <div>
      <h1>Настройки</h1>
      <p>Страница настроек</p>
    </div>
  );
};

export default Settings;