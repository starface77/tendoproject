import React from 'react';

const Users = () => {
  return (
    <div>
      <h1>Пользователи</h1>
      <p>Страница пользователей</p>
    </div>
  );
};

export default Users;