import React from 'react';

const Reviews = () => {
  return (
    <div>
      <h1>Отзывы</h1>
      <p>Страница отзывов</p>
    </div>
  );
};

export default Reviews;