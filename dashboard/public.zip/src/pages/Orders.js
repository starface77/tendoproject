import React from 'react';

const Orders = () => {
  return (
    <div>
      <h1>Заказы</h1>
      <p>Страница заказов</p>
    </div>
  );
};

export default Orders;