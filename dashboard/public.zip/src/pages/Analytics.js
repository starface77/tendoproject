import React from 'react';

const Analytics = () => {
  return (
    <div>
      <h1>Аналитика</h1>
      <p>Страница аналитики</p>
    </div>
  );
};

export default Analytics;