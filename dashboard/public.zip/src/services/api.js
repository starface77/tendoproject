/**
 * 🔧 API СЕРВИС ДЛЯ АДМИН ПАНЕЛИ
 * Все запросы к бэкенду для управления товарами
 */

import axios from 'axios';

// Базовая конфигурация API
const API_BASE_URL = 'http://localhost:5000/api/v1';

// Создаем экземпляр axios для админки
const adminApi = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Интерсептор для добавления токена
adminApi.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Интерсептор для обработки ответов
adminApi.interceptors.response.use(
  (response) => {
    return response.data;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Токен недействителен, выходим из системы
      localStorage.removeItem('admin_token');
      window.location.href = '/login';
    }
    
    return Promise.reject({
      message: error.response?.data?.error || error.message,
      status: error.response?.status,
      data: error.response?.data
    });
  }
);

// 📊 DASHBOARD API
export const dashboardApi = {
  // Получить статистику
  getStats: async () => {
    return adminApi.get('/admin/stats');
  },

  // Получить аналитику
  getAnalytics: async (period = '7d') => {
    return adminApi.get(`/admin/analytics?period=${period}`);
  }
};

// 🛍️ PRODUCTS API
export const productsApi = {
  // Получить все товары
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/products${queryString ? '?' + queryString : ''}`);
  },

  // Получить товар по ID
  getById: async (id) => {
    return adminApi.get(`/products/${id}`);
  },

  // Создать новый товар
  create: async (productData) => {
    return adminApi.post('/products', productData);
  },

  // Обновить товар
  update: async (id, productData) => {
    return adminApi.put(`/products/${id}`, productData);
  },

  // Удалить товар
  delete: async (id) => {
    return adminApi.delete(`/products/${id}`);
  },

  // Изменить статус товара (активировать/деактивировать)
  toggleStatus: async (id, isActive) => {
    return adminApi.patch(`/products/${id}/status`, { isActive });
  },

  // Массовые операции
  bulkDelete: async (ids) => {
    return adminApi.post('/products/bulk-delete', { ids });
  },

  // Экспорт товаров
  export: async (format = 'csv') => {
    return adminApi.get(`/products/export?format=${format}`, {
      responseType: 'blob'
    });
  }
};

// 📂 CATEGORIES API
export const categoriesApi = {
  // Получить все категории
  getAll: async () => {
    return adminApi.get('/categories');
  },

  // Получить категорию по ID
  getById: async (id) => {
    return adminApi.get(`/categories/${id}`);
  },

  // Создать новую категорию
  create: async (categoryData) => {
    return adminApi.post('/categories', categoryData);
  },

  // Обновить категорию
  update: async (id, categoryData) => {
    return adminApi.put(`/categories/${id}`, categoryData);
  },

  // Удалить категорию
  delete: async (id) => {
    return adminApi.delete(`/categories/${id}`);
  }
};

// 📋 ORDERS API
export const ordersApi = {
  // Получить все заказы
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/orders${queryString ? '?' + queryString : ''}`);
  },

  // Получить заказ по ID
  getById: async (id) => {
    return adminApi.get(`/orders/${id}`);
  },

  // Обновить статус заказа
  updateStatus: async (id, status) => {
    return adminApi.patch(`/orders/${id}/status`, { status });
  }
};

// 👥 USERS API
export const usersApi = {
  // Получить всех пользователей
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/users${queryString ? '?' + queryString : ''}`);
  },

  // Получить пользователя по ID
  getById: async (id) => {
    return adminApi.get(`/users/${id}`);
  },

  // Заблокировать/разблокировать пользователя
  toggleStatus: async (id, isActive) => {
    return adminApi.patch(`/users/${id}/status`, { isActive });
  }
};

// 💬 REVIEWS API
export const reviewsApi = {
  // Получить все отзывы
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/reviews${queryString ? '?' + queryString : ''}`);
  },

  // Одобрить отзыв
  approve: async (id) => {
    return adminApi.patch(`/reviews/${id}/approve`);
  },

  // Отклонить отзыв
  reject: async (id) => {
    return adminApi.patch(`/reviews/${id}/reject`);
  },

  // Удалить отзыв
  delete: async (id) => {
    return adminApi.delete(`/reviews/${id}`);
  }
};

// 📤 UPLOAD API
export const uploadApi = {
  // Загрузить изображение
  uploadImage: async (file, type = 'product') => {
    const formData = new FormData();
    formData.append('image', file);
    formData.append('type', type);

    return adminApi.post('/upload/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
  },

  // Удалить изображение
  deleteImage: async (imageUrl) => {
    return adminApi.delete('/upload/image', {
      data: { imageUrl }
    });
  }
};

// 🏪 SELLER APPLICATIONS API
export const sellerApplicationsApi = {
  // Получить все заявки
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/seller-applications${queryString ? '?' + queryString : ''}`);
  },

  // Получить заявку по ID
  getById: async (id) => {
    return adminApi.get(`/seller-applications/${id}`);
  },

  // Одобрить заявку
  approve: async (id, data = {}) => {
    return adminApi.put(`/seller-applications/${id}/approve`, data);
  },

  // Отклонить заявку
  reject: async (id, data = {}) => {
    return adminApi.put(`/seller-applications/${id}/reject`, data);
  },

  // Запросить дополнительные документы
  requestDocuments: async (id, data = {}) => {
    return adminApi.put(`/seller-applications/${id}/request-documents`, data);
  },

  // Получить статистику заявок
  getStats: async () => {
    return adminApi.get('/seller-applications/stats');
  }
};

// 🏬 SELLERS API
export const sellersApi = {
  // Получить всех продавцов
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return adminApi.get(`/sellers${queryString ? '?' + queryString : ''}`);
  },

  // Получить продавца по ID
  getById: async (id) => {
    return adminApi.get(`/sellers/${id}`);
  },

  // Заблокировать продавца
  suspend: async (id, data = {}) => {
    return adminApi.patch(`/sellers/${id}/suspend`, data);
  },

  // Разблокировать продавца
  unsuspend: async (id) => {
    return adminApi.patch(`/sellers/${id}/unsuspend`);
  },

  // Изменить комиссию
  updateCommission: async (id, commissionRate) => {
    return adminApi.patch(`/sellers/${id}/commission`, { commissionRate });
  },

  // Получить аналитику продавца
  getAnalytics: async (id, period = '30days') => {
    return adminApi.get(`/sellers/${id}/analytics?period=${period}`);
  }
};

// 🔐 AUTH API (для админ панели)
export const authApi = {
  // Логин админа (используем специальный админ логин)
  login: async (email, password) => {
    return adminApi.post('/auth/admin/login', { email, password });
  },

  // Получить текущего админа
  getMe: async () => {
    return adminApi.get('/auth/me');
  },

  // Выход из системы
  logout: async () => {
    return adminApi.post('/auth/logout');
  }
};

export default adminApi;
